package com.example.fromtoday;

import android.content.ClipData;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

public class Frag_Food extends Fragment {

    public List<ResultDB> rtList;
    private  void initLoadDB(){

        DataAdapter mDbHelper = new DataAdapter(getActivity().getApplicationContext());
        mDbHelper.createDatabase();
        mDbHelper.open();

        // db에 있는 값들을 model을 적용해서 넣는다.
        rtList = mDbHelper.getTableData();

        // db 닫기
        mDbHelper.close();
    }


    private View view;
    private TextView id;
    private TextView item;
    private TextView calorie;
    private TextView sum;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.frag_food, container, false);
        int total=0;
        String[] Calorie = new String[2];
        initLoadDB();

        id = view.findViewById(R.id.id);
        item = view.findViewById(R.id.item);
        calorie=view.findViewById(R.id.calorie);
        sum=view.findViewById(R.id.sum);
        for(int i = 0; i<2;i++) {
            String Id = rtList.get(i).getId()+"";
            String Item = rtList.get(i).getItem();
            Calorie[i] = rtList.get(i).getCalorie();

            id.setText(Id);
            item.setText(Item);
        }
        for(int i =0; i<2; i++){
            total+=Integer.parseInt(Calorie[i]);
        }
        sum.setText(""+total);

        return view;

    }
}
