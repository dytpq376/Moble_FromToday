package com.example.fromtoday;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import com.kakao.usermgmt.callback.UnLinkResponseCallback;

public class Frag_People extends Fragment {
    private View view;
    private ImageView profile;
    private TextView name;
    private TextView Age;
    private TextView gender;
    private TextView email;
    private TextView birthday;
    private Button button;
    private Button logout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.frag_people, container, false);
        setHasOptionsMenu(true);

        profile = view.findViewById(R.id.profile);
        name = view.findViewById(R.id.name);
        Age = view.findViewById(R.id.age);
        gender=view.findViewById(R.id.gender);
        email=view.findViewById(R.id.email);
        birthday=view.findViewById(R.id.birthday);

        button =view.findViewById(R.id.button);
        logout=view.findViewById(R.id.logout);

        if(getArguments()!=null) {
            //bundle = getArguments();
            String imageUrl = getArguments().getString("profile");
            String Name = getArguments().getString("name");
            String Email = getArguments().getString("email");
            String age = getArguments().getString("age");
            String Gender = getArguments().getString("gender");
            String Birth = getArguments().getString("birthday");
            if(imageUrl==null) {
                //profile.setImageResource(R.drawable.noneprofile);
                Glide.with(this).load(R.drawable.noneprofile).circleCrop().into(profile);
            }
            else {
                Glide.with(this).load(imageUrl).circleCrop().into(profile);
            }
            name.setText(Name);
            Age.setText(age);
            gender.setText(Gender);
            email.setText(Email);
            birthday.setText(Birth);
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserManagement.getInstance().requestUnlink(new UnLinkResponseCallback() {
                    @Override
                    public void onFailure(ErrorResult errorResult) {
                        //회원탈퇴 실패 시 동작
                    }

                    @Override
                    public void onSessionClosed(ErrorResult errorResult) {
                        //세션이 닫혔을 시 동작.
                    }

                    @Override
                    public void onNotSignedUp() {
                        //가입되지 않은 계정이 회원탈퇴를 요구할 경우 동작.
                    }

                    @Override
                    public void onSuccess(Long result) {
                        //회원탈퇴 성공 시 동작.
                    }
                });
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserManagement.getInstance()
                        .requestLogout(new LogoutResponseCallback() {
                            @Override
                            public void onCompleteLogout() {

                            }
                        });
                Intent intent =new Intent(getActivity(),Login.class);
                startActivity(intent);
            }
        });
        return view;

    }
}
