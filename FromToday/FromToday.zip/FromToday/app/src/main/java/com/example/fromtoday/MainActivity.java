package com.example.fromtoday;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    //---------------------------------------------------------------------------------------------
    // fields
    //---------------------------------------------------------------------------------------------
    // 네비게이션 사용을 위한 선언
    private BottomNavigationView bottomNavigationView; // 바텀 네비게이션 뷰
    private FragmentManager fm;
    private FragmentTransaction ft;
    // 각 뷰에 값을 사용하기 위한 객체선언
    private Frag_Food fragFood;
    private Frag_Sleep fragSleep;
    private Frag_Home fragHome;
    private Frag_Activity fragActivity;
    private Frag_People fragPeople;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bottomNavigationView = findViewById(R.id.bottom_Navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                // 선택된 메뉴 번호 전달
                switch (menuItem.getItemId()){
                    case R.id.food:
                        setFrag(0);
                        break;
                    case R.id.sleep:
                        setFrag(1);
                        break;
                    case R.id.home:
                        setFrag(2);
                        break;
                    case R.id.activity:
                        setFrag(3);
                        break;
                    case R.id.people:
                        setFrag(4);
                        break;
                }
                return true;
            }
        });
        // 각 뷰에 값을 사용하기 위한 객체생성
        fragFood = new Frag_Food();
        fragSleep = new Frag_Sleep();
        fragHome = new Frag_Home();
        fragActivity = new Frag_Activity();
        fragPeople = new Frag_People();
        // 첫 프래그먼트 화면을 무엇으로 지정해줄 것인지
        setFrag(2);

    }

    // 프래그먼트 교체가 일어나는 실행문
    private void setFrag(int n) {
        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        switch (n) {
            case 0 :
                ft.replace(R.id.main_frame, fragFood);
                ft.commit(); // 저장
                break;
            case 1 :
                ft.replace(R.id.main_frame, fragSleep);
                ft.commit(); // 저장
                break;
            case 2 :
                ft.replace(R.id.main_frame, fragHome);
                ft.commit(); // 저장
                break;
            case 3 :
                ft.replace(R.id.main_frame, fragActivity);
                ft.commit(); // 저장
                break;
            case 4 :
                //Login Activity 에서 넘어온 값 받기.
                Intent intent =getIntent();

                String strName=intent.getStringExtra("name");
                String strImage = intent.getStringExtra("profile");
                String strEmail=intent.getStringExtra("email");
                String strGender=intent.getStringExtra("gender");
                String strAge=intent.getStringExtra("age");
                String strBirth=intent.getStringExtra("birthday");

                Bundle bundle = new Bundle(6);
                bundle.putString("profile",strImage);
                bundle.putString("name",strName);
                bundle.putString("birthday",strAge);
                bundle.putString("email",strEmail);
                bundle.putString("gender",strGender);
                bundle.putString("age",strAge);
                bundle.putString("birthday",strBirth);

                Frag_People people = new Frag_People();
                people.setArguments(bundle);
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.main_frame,people).commit();

                break;
        }

    }



}