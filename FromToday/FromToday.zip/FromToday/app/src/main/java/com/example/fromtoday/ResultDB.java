package com.example.fromtoday;

public class ResultDB {
    public int id;
    public String item;
    public String calorie;

    public void setId(int id){
        this.id=id;
    }
    public void setItem(String item){
        this.item=item;
    }
    public void setCalorie(String calorie){
        this.calorie=calorie;
    }

    public int getId() {
        return id;
    }

    public String getCalorie() {
        return calorie;
    }

    public String getItem() {
        return item;
    }
}
